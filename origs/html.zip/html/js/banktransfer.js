var BankTransfer = {

	BAIL: function() {
				window.location = "/Main";
	},

	transferbanklist: function () {

	    var ss = "select A.GLACC,A.BankName,B.accounttype,A.BankAccountNum,";
	    ss += "(SELECT 'selected' from appconfig where mbfield1='Deposit' and mbvalue=a.GLACC) as vselect ";
	    ss += "from BankAccounts A LEFT JOIN accounttype B on A.BankAccountType=B.id WHERE 1=1 ";
	    $.ajax({
	        type: "POST",
	        url: MB.URLPoster(), 
	        data: { SQLStatement: ss }
	    }).done(function (msg) {
	        //var x = '';
	        $.each(JSON.parse(msg), function (id, value) {
	            $('#trncredit').append("<option value='" + value.GLACC + "'" + value.vselect + ">" + value.BankName + "</option>");
	            $('#trndebit').append("<option value='" + value.GLACC + "'" + value.vselect + ">" + value.BankName + "</option>");
	        });


	    });
	},


	posttransfer : function() {
	        if ($('#trnAmount').val() === "") {
                  bootbox.alert("Invalid amount!!");
                  return
            }
            if ($('#trnReference').val() === "") {
                  bootbox.alert("Invalid reference!!");
                  return
            }
	    if ($('#trndebit').val() == $('#trncredit').val())
	    {
		bootbox.alert("The same bank account not allowed!!");
                  return
	    }
	    // trntype 1 = cash

	    var SQL = "SELECT SUM(Amount) amount FROM BankAccTrn WHERE GLACC='" + $('#trncredit').val() + "' ";
	    //console.log(SQL);
	    //return;

	    $.ajax({
	        type: "POST",
	        url: MB.URLPoster(),
	        data: { SQLStatement: SQL },
	        success: function (data) {
	            // console.log(data);
	            $.each(JSON.parse(data), function (key, value) {
	                if (value.amount < $('#trnAmount').val()) {
	                    bootbox.alert("Not enough fund to transfer..");
	                    return
	                }
	            });
	        }
	    });
			
	    var sv = "EXEC UpdateMaster '" + $('#trndebit').val() + ":" + $('#trncredit').val() + "[1','" + $('#trnAmount').val() + "',3,'" + $('#trnReference').val() + "','" + $('#trnParticulars').val() + "','" + MB.getCookie('activeid') + "'";
			console.log(sv);
	    $.post(MB.URLPoster(),  //"http://" + MB.getCookie("serveraddress") + ":8080/Default.asmx/Exec",
                {
                    SQLStatement : sv
                }, function () { }).done(function () { bootbox.alert("Save Complete..", function(){window.location = "/Main";} ); }).complete(function () { });
	}
}
